package NWT;
public final class Recloser implements java.io.Serializable {
  public NWT.IdentifiedObject io;
  public NWT.UnitSymbol us;

  public Recloser() {
	  io = new NWT.IdentifiedObject();
	  us = new NWT.UnitSymbol(0);
  }

  public Recloser(NWT.IdentifiedObject _io, NWT.UnitSymbol _us) {
    io = _io;
    us = _us;
  }
}
