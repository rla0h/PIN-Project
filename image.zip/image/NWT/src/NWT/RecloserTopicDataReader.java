package NWT;
public interface RecloserTopicDataReader extends RecloserTopicDataReaderOperations, OpenDDS.DCPS.DataReaderEx {
}
