package NWT;
public class RecloserTopicTypeSupportImpl extends _RecloserTopicTypeSupportTAOPeer {
    public RecloserTopicTypeSupportImpl() {
        super(_jni_init());
    }
    private static native long _jni_init();
}
