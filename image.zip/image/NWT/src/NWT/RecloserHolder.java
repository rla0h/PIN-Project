package NWT;
public final class RecloserHolder {
  // TypeCode operations not currently implemented
  public Recloser value;
  public RecloserHolder() {}
  public RecloserHolder(Recloser initial) {
    value = initial;
  }
}
