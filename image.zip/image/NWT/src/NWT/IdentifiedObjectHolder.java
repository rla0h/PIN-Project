package NWT;
public final class IdentifiedObjectHolder {
  // TypeCode operations not currently implemented
  public IdentifiedObject value;
  public IdentifiedObjectHolder() {}
  public IdentifiedObjectHolder(IdentifiedObject initial) {
    value = initial;
  }
}
