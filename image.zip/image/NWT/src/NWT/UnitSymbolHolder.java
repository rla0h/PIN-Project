package NWT;
public final class UnitSymbolHolder {
  // TypeCode operations not currently implemented
  public UnitSymbol value;
  public UnitSymbolHolder() {}
  public UnitSymbolHolder(UnitSymbol initial) {
    value = initial;
  }
}
