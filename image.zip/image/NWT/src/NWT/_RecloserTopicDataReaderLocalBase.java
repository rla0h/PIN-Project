package NWT;
public abstract class _RecloserTopicDataReaderLocalBase extends org.omg.CORBA.LocalObject implements RecloserTopicDataReader {
  private String[] _type_ids = {"IDL:NWT/RecloserTopicDataReader:1.0", "IDL:OpenDDS/DCPS/DataReaderEx:1.0", "IDL:DDS/DataReader:1.0", "IDL:DDS/Entity:1.0"};

  public String[] _ids() { return (String[])_type_ids.clone(); }
}
