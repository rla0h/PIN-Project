package NWT;
public abstract class RecloserHelper {
  // Any and TypeCode operations not currently implemented
  public static String id() { return "IDL:NWT/Recloser:1.0"; }
}
