package NWT;
public final class RecloserTopicDataReaderHolder {
  // TypeCode operations not currently implemented
  public RecloserTopicDataReader value;
  public RecloserTopicDataReaderHolder() {}
  public RecloserTopicDataReaderHolder(RecloserTopicDataReader initial) {
    value = initial;
  }
}
