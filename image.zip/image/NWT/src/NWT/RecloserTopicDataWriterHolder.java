package NWT;
public final class RecloserTopicDataWriterHolder {
  // TypeCode operations not currently implemented
  public RecloserTopicDataWriter value;
  public RecloserTopicDataWriterHolder() {}
  public RecloserTopicDataWriterHolder(RecloserTopicDataWriter initial) {
    value = initial;
  }
}
