package NWT;
public class UnitSymbol implements java.io.Serializable {
  private static UnitSymbol[] __values = {
    new UnitSymbol(0),
    new UnitSymbol(1)
  };

  public static final int _UnitSymbol_none = 0;
  public static final UnitSymbol UnitSymbol_none = __values[0];

  public static final int _UnitSymbol_m = 1;
  public static final UnitSymbol UnitSymbol_m = __values[1];

  public int value() { return _value; }

  private int _value;

  public static UnitSymbol from_int(int value) {
    if (value >= 0 && value < 2) {
      return __values[value];
    } else {
      return new UnitSymbol(value);
    }
  }

  protected UnitSymbol(int value) { _value = value; }

  public Object readResolve()
      throws java.io.ObjectStreamException {
    return from_int(value());
  }

}
