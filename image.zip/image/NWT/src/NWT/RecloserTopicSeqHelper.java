package NWT;
public abstract class RecloserTopicSeqHelper {
  // Any and TypeCode operations not currently implemented
  public static String id() { return "IDL:NWT/RecloserTopicSeq:1.0"; }
}
