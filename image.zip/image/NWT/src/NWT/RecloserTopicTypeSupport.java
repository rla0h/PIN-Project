package NWT;
public interface RecloserTopicTypeSupport extends RecloserTopicTypeSupportOperations, OpenDDS.DCPS.TypeSupport {
}
