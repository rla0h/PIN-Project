package NWT;
public interface RecloserTopicTypeSupportOperations extends OpenDDS.DCPS.TypeSupportOperations {
}
