package NWT;
public final class RecloserTopicTypeSupportHolder {
  // TypeCode operations not currently implemented
  public RecloserTopicTypeSupport value;
  public RecloserTopicTypeSupportHolder() {}
  public RecloserTopicTypeSupportHolder(RecloserTopicTypeSupport initial) {
    value = initial;
  }
}
