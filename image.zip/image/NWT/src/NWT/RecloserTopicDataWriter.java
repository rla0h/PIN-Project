package NWT;
public interface RecloserTopicDataWriter extends RecloserTopicDataWriterOperations, DDS.DataWriter {
}
