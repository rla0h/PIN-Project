package NWT;
public final class RecloserTopic implements java.io.Serializable {
  public NWT.Recloser r;
  public int topicCount;

  public RecloserTopic() {
	  r = new NWT.Recloser();
  }

  public RecloserTopic(NWT.Recloser _r, int _topicCount) {
    r = _r;
    topicCount = _topicCount;
  }
}
