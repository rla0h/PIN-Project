package NWT;
public abstract class _RecloserTopicTypeSupportLocalBase extends org.omg.CORBA.LocalObject implements RecloserTopicTypeSupport {
  private String[] _type_ids = {"IDL:NWT/RecloserTopicTypeSupport:1.0", "IDL:OpenDDS/DCPS/TypeSupport:1.0", "IDL:DDS/TypeSupport:1.0"};

  public String[] _ids() { return (String[])_type_ids.clone(); }
}
