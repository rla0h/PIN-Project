package NWT;
public final class IdentifiedObject implements java.io.Serializable {
  public String description;
  public String mRID;
  public String name;
  public String aliasName;

  public IdentifiedObject() {}

  public IdentifiedObject(String _description, String _mRID, String _name, String _aliasName) {
    description = _description;
    mRID = _mRID;
    name = _name;
    aliasName = _aliasName;
  }
}
