package NWT;
public abstract class _RecloserTopicDataWriterLocalBase extends org.omg.CORBA.LocalObject implements RecloserTopicDataWriter {
  private String[] _type_ids = {"IDL:NWT/RecloserTopicDataWriter:1.0", "IDL:DDS/DataWriter:1.0", "IDL:DDS/Entity:1.0"};

  public String[] _ids() { return (String[])_type_ids.clone(); }
}
