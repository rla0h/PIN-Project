package NWT;
public abstract class IdentifiedObjectHelper {
  // Any and TypeCode operations not currently implemented
  public static String id() { return "IDL:NWT/IdentifiedObject:1.0"; }
}
