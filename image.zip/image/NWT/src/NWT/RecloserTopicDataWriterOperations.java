package NWT;
public interface RecloserTopicDataWriterOperations extends DDS.DataWriterOperations {
  int register_instance(NWT.RecloserTopic instance);
  int register_instance_w_timestamp(NWT.RecloserTopic instance, DDS.Time_t timestamp);
  int unregister_instance(NWT.RecloserTopic instance, int handle);
  int unregister_instance_w_timestamp(NWT.RecloserTopic instance, int handle, DDS.Time_t timestamp);
  int write(NWT.RecloserTopic instance_data, int handle);
  int write_w_timestamp(NWT.RecloserTopic instance_data, int handle, DDS.Time_t source_timestamp);
  int dispose(NWT.RecloserTopic instance_data, int instance_handle);
  int dispose_w_timestamp(NWT.RecloserTopic instance_data, int instance_handle, DDS.Time_t source_timestamp);
  int get_key_value(NWT.RecloserTopicHolder key_holder, int handle);
  int lookup_instance(NWT.RecloserTopic instance_data);
}
