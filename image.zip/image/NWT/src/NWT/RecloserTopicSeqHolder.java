package NWT;
public final class RecloserTopicSeqHolder {
  // TypeCode operations not currently implemented
  public NWT.RecloserTopic[] value;
  public RecloserTopicSeqHolder() {}
  public RecloserTopicSeqHolder(NWT.RecloserTopic[] initial) {
    value = initial;
  }
}
