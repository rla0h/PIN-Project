package NWT;
public abstract class UnitSymbolHelper {
  // Any and TypeCode operations not currently implemented
  public static String id() { return "IDL:NWT/UnitSymbol:1.0"; }
}
