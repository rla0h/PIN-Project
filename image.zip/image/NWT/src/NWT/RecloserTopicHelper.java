package NWT;
public abstract class RecloserTopicHelper {
  // Any and TypeCode operations not currently implemented
  public static String id() { return "IDL:NWT/RecloserTopic:1.0"; }
}
