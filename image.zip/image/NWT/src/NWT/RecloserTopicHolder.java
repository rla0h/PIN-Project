package NWT;
public final class RecloserTopicHolder {
  // TypeCode operations not currently implemented
  public RecloserTopic value;
  public RecloserTopicHolder() {}
  public RecloserTopicHolder(RecloserTopic initial) {
    value = initial;
  }
}
